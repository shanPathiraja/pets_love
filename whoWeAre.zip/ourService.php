<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<link href="css/ourService.css" rel="stylesheet" type="text/css">
<link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
</head>

<body>
	<div>
	<?php 
	
	include('navbar.php');
	?>
	
	</div>
	
	<div class="ourService-content">
	
	<div class="discription">
			<h2 align="center" >WELCOME TO PETS LOVE HOSPITAL</h2>
		<div class="service-image">
		
		
	
	</div>
		<div class="dis-content">
		
		<P>
			pets Love Animal hospital is dedicated to offer you a quality veterinary service at a reasonable price.  We are open all 7 days a week between 8.00am to 8.00pm and Poya days (8.00am – 5.00pm) to cater all your pet care needs.
			<br>
			<br>
			We are capable of vast number of services such as vaccination treatments to surgeries, digital X ray, Pet taxi and Ambulance services. We are dedicated to provide the best care for your pet companions throughout their lives.
			<br>
			<br>
			Please contact us on 071 123456789 for all your animal health care needs.
			
			</P>
	
		</div>
		
		
		</div>
		
		<div class="service">
			
			
				<div class="col" align="center">
						<div class="img" style="background-image: url('images/icons/medikit.png');%"></div>
					
						<h4>OPD Treatment</h4>
					<span>Companion animal medicine, diagnosis, treatments and preventive measures.</span>
			</div>
			
			<div class="col" align="center">
						<div class="img" style="background-image: url('images/icons/pet_surgery.png')"></div>
					
						<h4>ANIMAL SURGERIES</h4>
					<span>Companion animal surgeries.</span>
			</div>
			<div class="col" align="center">
						<div class="img" style="background-image: url('images/icons/lab.png')"></div>
					
						<h4>LABORATORY</h4>
					<span>Laboratory facilities for disease diagnosis.</span>
			</div>
			<div class="col" align="center">
						<div class="img" style="background-image: url('images/icons/x-ray.png')"></div>
					
						<h4>X-RAY</h4>
					<span>We are pleased to X-Ray services as a means of providing excellent care to our pets.</span>
			</div>
			<div class="col" align="center">
						<div class="img" style="background-image: url('images/icons/petFood.png')"></div>
					
						<h4>FOODS & ACCESSORIES</h4>
					<span>Availability of pet foods and various pet accessories.</span>
			</div>
			
			
		
		
		</div>
		
		
	</div>
		
	<div class=""
		 >
	<?php 
		
		include('footer.php');
		?>
	
	</div>
</body>
</html>