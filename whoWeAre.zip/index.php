<!doctype html>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
 "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
	<link href="css/font.css" rel="stylesheet" type="text/css">
<link href="css/navbar.css" rel="stylesheet" type="text/css">
<link href="css/main.css" rel="stylesheet" type="text/css">
<!--The following script tag downloads a font from the Adobe Edge Web Fonts server for use within the web page. We recommend that you do not modify it.--><script>var __adobewebfontsappname__="dreamweaver"</script><script src="http://use.edgefonts.net/averia-sans-libre:n3:default;arizonia:n4:default;alex-brush:n4:default;acme:n4:default;aclonica:n4:default.js" type="text/javascript"></script>
</head>

<body>
	<div>
	
	<?php 
	include("navbar.php");
	?>
	</div>
	
	<div class="main-slide">
		
		
	<div class="btn-appoiment " style="overflow: hidden; width: 450px;position:relative; ">
		
		

		
		
		<a class="btn-appoiment-cover" href="bookAnAppoiment.php" style="text-decoration: none;">
			<div class="btn-appoiment-cover" style="background-color:darkgreen; overflow: hidden; width: 400px;">
			
				<span class="btn-appoiment-cover" style="padding: 30px; width: 100%; color: white; display: block; ">MAKE AN APPOIMENT</span>
			</div>
		
		</a>
		
		</div>
		
			<div class="svg-wrapper">
				<a href="bookAnAppoiment.php">
  <svg height="100px" width="420px" xmlns="http://www.w3.org/2000/svg" >
    <rect class="shape" height="100px" width="420px" rx="30"  />
  
				</svg>
   </a>
</div>
		
		
	</div>
	
	<div class="service">
		
		<div class="round-container" align="center" >
		<center>
			<div class="roudIcon">
		<img src="images/icons/doc11004257.png" width="100px" style="margin-top: 40px">
		</div>
			</center>
		<div class="service-content">
			<h3>Qualified Doctors</h3>
			<span>
			Best care has qualified team of doctors and professionally trained team of Veterinary Assistants and Dog Handlers to offer you the best service.
			
			</span>
			</div>
		</div>
		<div class="round-container" align="center" >
			<center>
		<div class="roudIcon">
		<img src="images/icons/365D23575839.png" width="120px" style="margin-top:35px ">
		</div></center>
		<div class="service-content">
			<h3>365D OPD</h3>
			<span>
			Our OPD unit is opened all around the year with a well trained doctors and staff to help you when your pet is sick. Our working hours. 8.00am to 8.00pm – Poya Days 8.00am to 5.00pm
			</span>
			</div>
		</div>
		<div class="round-container" align="center" >
		<center>
			<div class="roudIcon">
		<img src="images/icons/hart.png" width="90px" style="margin-top: 55px">
		</div>
			</center>
		<div class="service-content">
			<h3>Pet Friendly Service</h3>
			<span>Our hospital and OPD section is a pet-friendly environment that will keep your pet calm during the treatments. Now your cat can be consulted in our new cat treatment area.
			</span>
			</div>
		</div>
		<div class="round-container" align="center" >
			<center>
		<div class="roudIcon">
		<img src="images/icons/cyringer125018.png" width="100px" style="margin-top: 40px">
		</div>
				</center>
		<div class="service-content">
			<h3>Advanced Technology</h3>
			
			<span>Our modern laboratory facilities will help our clients to get the laboratory tests done in one place without going anywhere else.
			</span>
			</div>
			
			
		</div>
		
		
	
	</div>
	
	<div class="include-footer">
	<?php 
		include("footer.php");
		
		?>
	</div>
	
	
</body>
</html>