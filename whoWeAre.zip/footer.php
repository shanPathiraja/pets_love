<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<link href="css/footter.css" rel="stylesheet" type="text/css">
</head>

<body>
	<div class="footter-top">
	<div class="footer-container">
		
		
		<h3 class="fotter-title">About</h3>
		<center>
			<div class="tittle-after" align="center"></div>
			</center>
		<div class="foter-content">
			<hr>
		<span>Pets love Animal hospital was established in October 2010 aiming to provide better and professional service for all the pet owners. We are equipped with modern technology and professional qualified doctors to offer you a good service.</span>
		</div>
		</div>
		<div class="footer-container">
		<h3 class="fotter-title">Useful Links</h3>
			<center>
			<div class="tittle-after" align="center"></div>
			</center>
		
			<div class="foter-content">
			<hr>
				<a href="#">Home</a>
			<hr>
			<a href="#">Who we are</a>
			<hr>
			<a href="#">Our service</a>
			<hr>
			<a href="#">Shop</a>
			<hr>
				</div>
		</div>
		<div class="footer-container">
		<h3 class="fotter-title">Get In Touch</h3>
		<center>
			<div class="tittle-after" align="center"></div>
			</center>
			<div class="foter-content">
				<hr>
				<span> Akkara 111,Pandulagama ,Anuradhapura</span>
				<hr>
				<span>+94 7123456798</span>
				<hr>
				<span>info@petslove.com</span>
				<hr>
			</div>
			
			
			
		</div>
	</div>
	<div class = "footter-down">
		<div class="fotter-down-content">
		<span>Copyright © 2020 pets Loves Hospital | Powered by ShanCreation</span>
		</div>
		
		<div class="fotter-down-socialmedia">
		<i><img class="foot-content-icon" src="images/icons/icons8_facebook_32px.png"></i> 
				<i><img class="foot-content-icon" src="images/icons/icons8_google_plus_24px.png"></i>
				<i><img class="foot-content-icon" src="images/icons/icons8_twitter_circled_50px_1.png"></i>
					<i><img class="foot-content-icon" src="images/icons/icons8_youtube_100px.png"></i>
		
		</div>
		
	</div>
</body>
</html>