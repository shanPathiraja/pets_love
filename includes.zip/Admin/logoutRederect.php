<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Pets Love Admin Panel</title>
</head>

<body>
	
	<center>
	<h3> You dont have Permission to View this content Please Login</h3>
		
		<h4>to login click <a href="login.php"> here </a></h4>
	
	</center>
</body>
</html>